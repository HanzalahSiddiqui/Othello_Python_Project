import random
# Function to initialize the board
def initialize_board():
    """
    Initialize the game board with starting positions.
    """
    board = [[' ' for _ in range(8)] for _ in range(8)]
    board[3][3] = board[4][4] = '●'
    board[3][4] = board[4][3] = '○'
    return board

# Function to make a move on the board
def make_move(board, row, col, symbol):
    """
    Make a move on the board.
    """
    board[row][col] = symbol
    return board

def determine_winner(board):
    """
    Determine the winner based on the counts of '●' and '○' tokens on the board.
    """
    count_player1 = sum(row.count('●') for row in board)
    count_player2 = sum(row.count('○') for row in board)

    if count_player1 > count_player2:
        return '●'
    elif count_player1 < count_player2:
        return '○'
    else:
        return None

def is_board_full(board):
    """
    Check if the board is full.

    Args:
        board (list): The game board.

    Returns:
        bool: True if the board is full, False otherwise.
    """
    for row in board:
        if ' ' in row:
            return False
    return True

def any_valid_moves(board, symbol):
    """
    Check if there are any valid moves for a given symbol.

    Args:
        board (list): The game board.
        symbol (str): The player's symbol.

    Returns:
        bool: True if there are valid moves, False otherwise.
    """
    for row in range(len(board)):
        for col in range(len(board[0])):
            if is_valid_move(board, row, col, symbol):
                return True
    return False


def human_vs_random():
    """
    Function to play a game between a human and a random player.
    """
    board = initialize_board()
    turn = 0
    while True:
        print_board(board)
        if turn % 2 == 0:
            player = 'Player 1'
            symbol = BLACK
            print(f"{player}'s turn:")
            row, col = get_human_move(board, symbol)
        else:
            player = 'Player 2'
            symbol = WHITE
            print(f"{player}'s turn:")
            row, col = get_random_move(board, symbol)
            print(f"Move made by {player}: {row}, {col}")
        board[row][col] = symbol
        if is_game_over(board):
            print_board(board)
            winner = get_winner(board)
            if winner == 'Tie':
                print("It was a tie")
                return 0
            else:
                print(f"{winner} Wins")
                return 1 if winner == 'Player 1' else 2
        turn += 1


def ai_vs_random():
    """
    Play a game between AI and a random player.
    """
    board = initialize_board()
    print_board(board)
    symbol = '●'  # AI symbol
    while True:
        if is_board_full(board) or not any_valid_moves(board, symbol):
            winner = determine_winner(board)
            if winner == '●':
                print("AI wins!")
            elif winner == '○':
                print("Random player wins!")
            else:
                print("It's a tie!")
            break

        # AI's turn
        row, col = get_ai_move(board, symbol)
        if row is not None and col is not None:
            make_move(board, row, col, symbol)
            print(f"AI's move: {row}, {col}")
            print_board(board)
        else:
            print("AI cannot make a move.")
            break

        # Random player's turn
        row, col = get_random_move(board, '○')
        if row is not None and col is not None:
            make_move(board, row, col, '○')
            print(f"Random player's move: {row}, {col}")
            print_board(board)
        else:
            print("Random player cannot make a move.")
            break


    # Determine the winner
    winner = determine_winner(board)
    if winner == '●':
        print("Player 1 Wins")
        return 1
    elif winner == '○':
        print("Player 2 Wins")
        return 2
    else:
        print("It was a tie")
        return 0


BLACK = '●'
WHITE = '○'

def random_vs_random():
    """
    Function to play a game of Othello between two random players.
    """
    board = initialize_board()
    symbol = BLACK  
    while True:
        print_board(board)
        if not any_valid_moves(board, symbol):
            print("No valid moves available for", symbol)
            break
        
        row_col = get_random_move(board, symbol)
        if row_col is not None:
            row, col = row_col
            make_move(board, row, col, symbol) 
            print(f"Move made by {symbol}: {row}, {col}")
            symbol = WHITE if symbol == BLACK else BLACK  # Toggle between BLACK and WHITE symbols
        else:
            print("No valid moves available for", symbol)
            break
    
    print("Game over!")




def print_board(board):
    """
    Function to print the current state of the board.
    """
    print("   0 1 2 3 4 5 6 7")
    print("  +-+-+-+-+-+-+-+-+")
    for i in range(8):
        print(f"{i} |{'|'.join(board[i])}|")
        print("  +-+-+-+-+-+-+-+-+")

def get_human_move(board, symbol):
    """
    Function to get a valid move from the human player.
    """
    while True:
        try:
            row = int(input("Enter row number: "))
            col = int(input("Enter column number: "))
            if is_valid_move(board, row, col, symbol):
                return row, col
            else:
                print("Invalid move! Try again.")
        except ValueError:
            print("Invalid input! Please enter a number.")

def get_ai_move(board, symbol):
    """
    Get a random valid move for the AI player.
    """
    max_attempts = 100
    attempts = 0
    while attempts < max_attempts:
        row = random.randint(0, 7)
        col = random.randint(0, 7)
        if is_valid_move(board, row, col, symbol):
            return row, col
        attempts += 1
    # If no valid move found after maximum attempts, return None
    return None

def get_random_move(board, symbol):
    """
    Function to get a random valid move from the AI or random player.
    """
    valid_moves = [(i, j) for i in range(8) for j in range(8) if is_valid_move(board, i, j, symbol)]
    if valid_moves:
        return random.choice(valid_moves)
    else:
        return None  # No valid moves available




def is_valid_move(board, row, col, symbol):
    if row < 0 or row >= 8 or col < 0 or col >= 8 or board[row][col] != ' ':
        return False
    return True


def is_game_over(board):
    """
    Function to check if the game is over.
    """
    # Implementation to check if the game is over
    pass

def get_winner(board):
    """
    Function to determine the winner of the game.
    """
    # Implementation to determine the winner
    pass

def main():
    """
    Main function to choose the game mode and start the game.
    """
    print("Welcome to Othello")
    print("Choose a game mode:")
    print("1. Human vs Random")
    print("2. AI vs Random")
    print("3. Random vs Random")

    choice = input("Enter your choice (1, 2, or 3): ")

    if choice == '1':
        print("Starting Human vs Random game...")
        result = human_vs_random()
        print(f"Game Over! Result: {result}")
    elif choice == '2':
        print("Starting AI vs Random game...")
        result = ai_vs_random()
        print(f"Game Over! Result: {result}")
    elif choice == '3':
        print("Starting Random vs Random game...")
        result = random_vs_random()
        print(f"Game Over! Result: {result}")
    else:
        print("Invalid choice! Please choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
